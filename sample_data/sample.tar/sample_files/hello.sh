#!/bin/bash
echo "Hello from the sample archive!"
echo "Current date: $(date)"
echo "Files in this directory:"
ls -la
