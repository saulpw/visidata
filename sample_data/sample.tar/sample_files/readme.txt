Sample Archive Contents
======================

This is a demonstration tar archive containing:
- Text files (.txt)
- Configuration files (.conf)
- Data files (.csv)
- Script files (.sh)

Created for testing and educational purposes.
