# Changelog

## Version 1.0
- Initial sample archive creation
- Added basic file types
- Included documentation

## Features
- Cross-platform compatibility
- Standard tar format
- Educational content
